String.prototype.format = function(args) {
var result = this;
if (arguments.length > 0)
{
for (var i = 0; i < arguments.length; i++)
{
if (arguments[i] != undefined) {
var reg = new RegExp("({[" + i + "]})", "g");
result = result.replace(reg, arguments[i]);
}
}
}
return result;
}
function showOrHideRowDiv(action, RowDiv)
{
var subWidget = RowDiv.find("*[id!='']")
if ( action == "show" )
{
RowDiv.showIt(true);
subWidget.removeClass("PostIgnore");
}
else
{
RowDiv.showIt(false);
subWidget.addClass("PostIgnore");
}
}
function colonStripping(str)
{
var colonLocation = str.indexOf(":");
if ( colonLocation != -1 )
{
return str.substring(0, colonLocation);
}
return str;
}
jQuery.fn.showIt = function(show) {
if (show)
{
$(this).css("display", "");
}
else
{
$(this).css("display", "none");
}
}
jQuery.fn.cloneWithSuffix = function(suffix, splitter) {
var source = $(this);
var clone = source.clone(true);
clone.attr("id", clone.attr("id")+"_"+suffix);
if ( undefined == splitter )
{
splitter = ":";
}
var idElems = clone.find("*[id!='']");
idElems.each(function(){
var idEle = $(this);
var oldID = idEle.attr("id");
if (oldID != undefined)
{
var newID = oldID + splitter + suffix;
idEle.attr("id", newID);
}
var oldName = idEle.attr("name");
if (oldName != undefined)
{
var newName = oldName + splitter + suffix;
idEle.attr("name", newName);
}
});
labelForElems = clone.find("label");
labelForElems.each(function(){
var labelForEle = $(this);
var oldFor = labelForEle.attr("for");
if (oldFor != undefined)
{
var newFor = oldFor + splitter + suffix;
labelForEle.attr("for", newFor);
}
});
clone.trigger("applyPromptCheckJSON", [clone]);
return clone;
}
function initial_sceneTip()
{
$(".sceneTip_container").each(function(){
$(this).hide();
});
$(".sceneTipLink").each(function(){
var sceneTipLinkContent = $(this).children();
sceneTipLinkContent.unbind( "click" );
sceneTipLinkContent.click(function(event){
event.preventDefault();
$(this).parent().next().slideToggle("normal");
});
});
$(".sceneTip_close").each(function(){
var sceneTip_closeLink = $(this).children();
sceneTip_closeLink.unbind( "click" );
sceneTip_closeLink.click(function(){
$(this).parent().parent().slideUp("normal");
});
});
}
function succHintShow(template)
{
var PostFeedbackOBJ = $(".succHint",template);
PostFeedbackOBJ.fadeIn(1000);
window.setTimeout(
function() {
PostFeedbackOBJ.fadeOut(1000);
PostFeedbackOBJ.hide();
},
2000
);
}
jQuery.fn.dataTransfer = function(URL, transferType, success_func, error_func, IfShowWaitTip, async, dataType){
if ( !URL || URL == "" )
{
consoleLog("[dataTransfer]URL is illegal!");
return;
}
var IfShowWaitTipTmp = IfShowWaitTip;
if ( IfShowWaitTipTmp == undefined )
{
IfShowWaitTipTmp = true;
}
var asyncTemp = async;
if ( asyncTemp == undefined )
{
asyncTemp = true;
}
if ( !dataType )
{
var dataType = "xml";
}
if ( IfShowWaitTipTmp == true )
{
showWaitTip(true);
}
var Head = $(this);
$.ajax({
url:URL,
type: transferType,
dataType: dataType,
timeout: 30000,
async: asyncTemp,
cache:false,
error: function(){
if ($.isFunction(error_func))
{
error_func();
}
else
{
if (Head != undefined)
{
var ajaxTransferFailHint = "&?public_076;";
var externErrorHint = $(".externErrorHint",Head);
if ( externErrorHint != undefined )
{
$("span",externErrorHint).text(ajaxTransferFailHint);
externErrorHint.showIt(true);
}
}
showWaitTip(false);
}
},
success: function(xml){
success_func(xml);
if ( IfShowWaitTipTmp == true )
{
showWaitTip(false);
}
}
});
}
jQuery.fn.fillDataByType = function(data){
var Elems = $(this);
if (Elems.is("input"))
{
switch (Elems.attr("type"))
{
case "hidden":
case "text":
case "password":
{
Elems.attr("value", data);
if (typeof(Elems.attr("title")) != "undefined")
{
Elems.attr("title", data);
}
break;
}
case "checkbox":
{
if( 1 == data )
{
Elems.attr("checked", true);
}
else
{
Elems.attr("checked", false);
}
Elems.attr("value",data);
break;
}
default:
{
break;
}
}
}
else if (Elems.is("span"))
{
Elems.text(data);
if (typeof(Elems.attr("title")) != "undefined")
{
Elems.attr("title", data);
}
}
else if (Elems.is("a"))
{
Elems.text(data);
Elems.attr("href",data);
}
else if (Elems.is("select"))
{
Elems.attr("value", data);
}
else if (Elems.is("textarea"))
{
Elems.attr("value", data);
}
else if (Elems.is("label"))
{
Elems.text(data);
}
else if (Elems.is("div"))
{
var radioObj = $("input[type=radio]", Elems);
radioObj.each(function(){
var thisObj = $(this);
if (thisObj.attr("value") == data)
{
thisObj.attr("checked", "checked");
}
else
{
thisObj.removeAttr("checked");
}
});
}
else
{
}
}
jQuery.fn.fillDataByOBJID = function(xml, OBJIDs, Clone, suffix, splitter){
if ( undefined == splitter )
{
splitter = ":";
}
for (var i=0; i<OBJIDs.length; i++)
{
var OBJID = OBJIDs[i];
var OBJIDSplit = OBJID.split(":");
var OBJIDIndex = 0;
var isSplitterExist = 0;
if ( OBJIDSplit.length == 2 )
{
OBJID = OBJIDSplit[0];
OBJIDIndex = parseInt(OBJIDSplit[1]);
isSplitterExist = 1;
}
var OBJs = $(xml).find(OBJID);
if ( OBJs.length == 0 )
{
continue;
}
var OBJ;
if ( OBJIDIndex < OBJs.length )
{
OBJ = OBJs.get(OBJIDIndex);
}
else
{
continue;
}
var instances;
if ( 1 == isSplitterExist )
{
instances = $("Instance", OBJ);
}
else
{
instances = $("Instance", OBJs);
}
if ( instances.length <= suffix
|| suffix < 0 )
{
consoleLog("suffix off normal upper!!");
continue;
}
var InstOBJ = instances.eq(suffix);
InstOBJ.find("ParaName").each(function(){
var ParaName = $(this).text();
var ParaValue = $(this).next().text();
var Elems = $("[id^='"+ParaName+splitter+"']", Clone);
if ( Elems.length == 0 )
{
Elems = $("#"+ParaName, Clone);
}
if ( Elems.length > 0 )
{
Elems.fillDataByType(ParaValue);
}
});
}
}
jQuery.fn.createPageDataByClone = function(RuleNum,DataOBJID,xml,fillDataByCustom){
var Head = $(this);
var HeadID = Head.attr("id");
var TemplateOBJ = $("#template_"+HeadID);
$("#_InstNum", Head).attr("value",RuleNum);
for (var i=0; i<RuleNum; i++)
{
var clone = TemplateOBJ.cloneWithSuffix(i);
TemplateOBJ.before(clone);
clone.fillDataByOBJID(xml ,DataOBJID, clone, i);
if ( $.isFunction(fillDataByCustom) )
{
fillDataByCustom(i,clone);
}
else
{
clone.trigger("fillDataByCustom",[i,clone]);
}
clone.showIt(true);
}
}
jQuery.fn.hasError = function(xml,location){
var ContentContainer = $(this);
var cmapiErrorContainer = $(".errorHint",ContentContainer);
if (location == "externErrorHint")
{
cmapiErrorContainer = $(".externErrorHint",ContentContainer);
}
var ErrorString = xml.getElementsByTagName("IF_ERRORSTR")[0].childNodes[0].nodeValue;
var ErrorParam = xml.getElementsByTagName("IF_ERRORPARAM")[0].childNodes[0].nodeValue;
if ( ErrorString == "SUCC" )
{
cmapiErrorContainer.showIt(false);
return 0;
}
else if ( ErrorString == "SessionTimeout" )
{
window.location.href = "/";
return 1;
}
else
{
var cmapiErrorContainerHtml = "";
var paraString = "";
if ( ErrorParam != "SUCC")
{
ErrorString = "&?cmret_101;"
var paraLabel = ContentContainer.find("label[for^='"+ErrorParam+"\\:']");
if ( paraLabel.length <= 0 )
{
paraLabel = ContentContainer.find("label[for='"+ErrorParam+"']");
}
if ( paraLabel.length > 0 )
{
paraLabel.each(function(){
var labelTmp = $(this);
if (labelTmp.hasClass("error"))
{
return true;
}
paraString = labelTmp.text();
});
}
else
{
ErrorString = "&?cmret_001;";
}
cmapiErrorContainerHtml = ErrorString.format(paraString);
}
else
{
if ( "FAIL" == ErrorString
|| "&?cmret_101;" == ErrorString )
{
ErrorString = "&?cmret_001;";
}
cmapiErrorContainerHtml = ErrorString;
}
$("span",cmapiErrorContainer).text(cmapiErrorContainerHtml);
cmapiErrorContainer.showIt(true);
return 1;
}
}
jQuery.fn.ShouldPostIgnore = function(){
if($(this).hasClass("PostIgnore"))
{
return true;
}
return false;
}
jQuery.fn.InitialPostData = function(actionType){
var AND = "&";
var template = $(this);
var PostData = "IF_ACTION=" + actionType;
var formInputContent = template.find("input,select");
formInputContent.each(function(key){
var Elems = $(this);
if ( Elems.ShouldPostIgnore() )
{
return true;
}
var ElemsID = Elems.attr("id");
if ( Elems.attr("type") == "radio" )
{
if ( Elems.is(':checked') )
{
ElemsID = Elems.attr("name");
}
else
{
return true;
}
}
var ElemsMainID = colonStripping(ElemsID);
var ElemsValue = "";
if ( Elems.is("input") )
{
switch (Elems.attr("type"))
{
case "hidden":
case "text":
case "password":
case "radio":
{
ElemsValue = Elems.attr("value");
break;
}
case "checkbox":
{
if( Elems.attr('checked')=="checked"
|| Elems.attr('checked')==true )
{
ElemsValue = 1;
}
else
{
ElemsValue = 0;
}
break;
}
default:
{
break;
}
}
}
else if ( Elems.is("select") )
{
ElemsValue = Elems.val();
}
else
{
consoleLog("when create post data, find not support elements type!!");
}
var NameValueJson = {
"ElemsMainID": ElemsMainID,
"ElemsValue": ElemsValue
};
template.trigger("PostDataChangeByCustom",[NameValueJson,template]);
var RealElemsValue = encodeURIComponent(NameValueJson.ElemsValue);
PostData += AND + ElemsMainID + "=" + RealElemsValue;
});
return PostData;
}
function RefreshClickHandle(Head)
{
$(".Btn_refresh", Head).each(function(){
$(this).unbind("click");
$(this).bind("click", function(){
var HeadID = Head.attr("id");
Head.find("[id^='template_"+HeadID+"_']").each(function(){
$(this).remove();
});
var ServerAddr = $("address span", Head).text();
Head.dataTransfer(ServerAddr,
"GET",
Head.succfunction,
Head.failfunction,
undefined,
true);
});
})
}
function initial_special_password(Head)
{
$(".SpecialPassword", Head).each(function(){
$(this).mouseup( function(){
if(this.focused){
this.focused=false;
return false;
}
});
});
$(".SpecialPassword", Head).each(function(){
$(this).focus( function(){
this.select();
this.focused=true;
});
});
}
function initial_button(buttonType, Head)
{
if ( !Head )
{
consoleLog("incoming para:Head is not defined!");
return;
}
var buttonClass = "";
var eventHandler = "";
if ( buttonType == "Apply" )
{
buttonClass = "Btn_apply";
eventHandler = "fillDataByApplyResult";
}
else if ( buttonType == "Cancel" )
{
buttonClass = "Btn_cancel";
eventHandler = "fillDataByCancelResult";
}
else if ( buttonType == "Delete" )
{
buttonClass = "Btn_delete";
eventHandler = "fillDataByDeleteResult";
}
else
{
}
$("."+buttonClass, Head).each(function(){
$(this).unbind("click");
$(this).bind("click",function(event){
var buttonOBJ = $(this);
if (buttonOBJ.hasClass("disableBtn")
||buttonOBJ.hasClass("disableLongBtn"))
{
return;
}
var Head = buttonOBJ.parents(".HeadDIV");
var template = buttonOBJ.parents("[id^='template']");
var ActionBeforePostResult = {result: "Process"};
if ( buttonType == "Apply" )
{
var formOBJ = $(".form_content", template);
if ( formOBJ.length > 0 && false == formOBJ.valid() )
{
return;
}
else
{
var formObj = $(".form_content", template);
var txtInputObjs = $("input[type='text']", formObj);
txtInputObjs.each(function(){
var obj = $(this);
var rules = obj.rules();
if (rules.integer)
{
var intStr = obj.val();
var sign, digits;
if ( intStr.charAt(0) == '-' )
{
sign = "-";
digits = intStr.substring(1);
}
else
{
sign = "";
digits = intStr;
}
while(digits.charAt(0) == '0' && digits.length > 1)
{
digits = digits.substring(1);
}
intStr = sign + digits;
obj.val(intStr);
}
});
}
}
template.trigger("ActionBeforePostByCustom",[template,ActionBeforePostResult]);
if (ActionBeforePostResult.result != "Process")
{
return;
}
var ThisInstID = $("[id^='_InstID']",template).attr("value");
if ( ThisInstID == -1
&& (buttonType == "Cancel" || buttonType == "Delete") )
{
template.remove();
return;
}
var ServerAddr = $("address span", Head).text();
dataPost(buttonType, eventHandler, ServerAddr, template);
});
});
}
function dataPost(actionType, PostSuccHandler, ServerAddr, template, PostData, IfShowWaitTip, asyncFlag)
{
var IfShowWaitTipTmp = IfShowWaitTip;
if ( IfShowWaitTipTmp == undefined )
{
IfShowWaitTipTmp = true;
}
if (asyncFlag == undefined)
{
asyncFlag = true;
}
var PostDataTmp = "";
if (PostData == undefined)
{
template.trigger("hiddenValueChangeByCustom",[template, actionType]);
PostDataTmp = template.InitialPostData(actionType);
}
else
{
PostDataTmp = PostData;
}
PostDataTmp += "&_VENUS_TOKEN="+_VENUS_tmpToken;
if ( IfShowWaitTipTmp == true )
{
showWaitTip(true);
}
$.ajax({
url:ServerAddr,
type: 'POST',
data: PostDataTmp,
dataType: 'xml',
async: asyncFlag,
timeout: 30000,
cache:false,
error: function(){
var ajaxPostFailHint = "&?public_076;";
var errorContainer = $(".errorHint",template);
var changeArea = $(".ChangeArea",template);
var collapsibleInst = $(".collapsibleInst",template);
if ( errorContainer != undefined )
{
$("span", errorContainer).text(ajaxPostFailHint);
errorContainer.showIt(true);
if ( changeArea != undefined )
{
changeArea.showIt(true);
}
if ( collapsibleInst != undefined )
{
collapsibleInst.addClass("instNameExp");
}
template.showIt(true);
}
showWaitTip(false);
},
success: function(xml){
template.trigger(PostSuccHandler,[xml,template]);
if (template.hasError(xml) == 0)
{
$(".SpecialPassword", template).each(function(i)
{
$(this).attr("value", "						");
});
}
var formObj = $(".form_content", template);
var errObjs = $(".errorLabelWraper > .error", formObj);
errObjs.attr("style", "display:none");
if ( IfShowWaitTipTmp == true )
{
showWaitTip(false);
}
}
});
}
function FocusAutoJump(obj,value,e)
{
var objJQ = $(obj);
var objId = colonStripping(obj.id);
var objParent = objJQ.parent();
var valLen = value.length;
var idKeyword = objId.replace(/\d+$/,"");
var curIndex = objId.match(/\d+$/);
var nextIndex = parseInt(curIndex, 10) + 1;
var nextID = idKeyword + nextIndex;
var nextOBJ = $("[id^='"+nextID+"']",objParent);
var prevIndex = parseInt(curIndex, 10);
if (prevIndex > 0)
{
prevIndex = prevIndex - 1;
}
var prevID = idKeyword + prevIndex;
var prevOBJ = $("[id^='"+prevID+"']",objParent);
var keynum;
if(window.event)
{
keynum = e.keyCode;
}
else if(e.which)
{
keynum = e.which;
}
var temp = value.substring(valLen-1, valLen);
if(("."==temp) && (objJQ.attr("class").indexOf("ip") != -1) && (0 != valLen))
{
objJQ.attr("value", value.substring(0, valLen-1))
if("."!=value)
{
nextOBJ.focus();
nextOBJ.select();
}
}
if (valLen == obj.maxLength)
{
if ( nextOBJ.length <= 0 )
{
return;
}
if (9 != keynum && 16 != keynum && 35 != keynum && 36 != keynum &&
37 != keynum && 38 != keynum && 39 != keynum && 40 != keynum &&
46 != keynum && 8 != keynum && objJQ.valid() == 1)
{
nextOBJ.focus();
nextOBJ.select();
}
}
else if (valLen == 0 && 37 == keynum)
{
if (prevOBJ.length <= 0)
{
return;
}
prevOBJ.focus();
prevOBJ.select();
}
else
{
return;
}
}
function autoJumpBack(obj,value,e)
{
var objJQ = $(obj);
var objId = colonStripping(obj.id);
var objParent = objJQ.parent();
var valLen = value.length;
var idKeyword = objId.replace(/\d+$/,"");
var curIndex = objId.match(/\d+$/);
var prevIndex = parseInt(curIndex, 10);
if (prevIndex > 0)
{
prevIndex = prevIndex - 1;
}
var prevID = idKeyword + prevIndex;
var prevOBJ = $("[id^='"+prevID+"']",objParent);
var keynum;
if(window.event)
{
keynum = e.keyCode;
}
else if(e.which)
{
keynum = e.which;
}
if (8 == keynum && valLen == 0)
{
if ( prevOBJ.length <= 0 )
{
return;
}
prevOBJ.focus();
prevOBJ.select();
}
}
jQuery.fn.FillIPorMacDataBySplit = function(subid,Delimiter,length) {
var IPOBJ = $(this);
if ( IPOBJ.length == 0 )
{
return;
}
var containerOBJ = IPOBJ.parents("[id^='template_']");
var value = IPOBJ.attr("value");
if ( !value )
{
return
}
var temp= value.split(Delimiter);
if (length != temp.length)
{
return;
}
for(var i=0; i<length; i++)
{
var fillOBJ = $("[id^='"+subid+i+"']",containerOBJ);
fillOBJ.attr("value",temp[i]);
}
}
jQuery.fn.FillIPorMacDataCombination = function(subid,Delimiter,length) {
var IPOBJ = $(this);
if ( IPOBJ.length == 0 )
{
return;
}
var containerOBJ = IPOBJ.parents("[id^='template_']");
var temp = "";
for(var i=0; i<length; i++)
{
var tempObj = $("[id^='"+subid+i+"']",containerOBJ);
if(0!=i)
{
temp += Delimiter;
}
var tempValue = tempObj.attr("value");
if ( !tempValue )
{
tempValue = "";
}
temp += tempValue;
tempObj.addClass("PostIgnore");
}
IPOBJ.attr("value",temp);
return temp;
}
jQuery.fn.setPromptCheckJSON = function(checkJSONTempObj, template){
var templateID = template.attr("id");
var instIndex = templateID.match(/\d+$/);
var checkJSONInstObj = {"groups":{}, "rules":{}, "messages":{}};
if ( checkJSONTempObj.groups != undefined )
{
$.each(checkJSONTempObj.groups, function(key, value) {
var valJSONStr = value;
var idArr = value.split(" ");
for ( var i=0; i<idArr.length; i++ )
{
idArr[i] += ":"+instIndex;
}
valJSONStr = idArr.join(" ");
var parameterJSON = eval("({'"+key+":"+instIndex+"':'" + valJSONStr + "'})");
$.extend(checkJSONInstObj.groups, parameterJSON);
});
}
if ( checkJSONTempObj.rules != undefined )
{
$.each(checkJSONTempObj.rules, function(key, value) {
var valJSONStr = $.toJSON(value);
var parameterJSON = eval("({'"+key+":"+instIndex+"':" + valJSONStr + "})");
$.extend(checkJSONInstObj.rules, parameterJSON);
});
}
if ( checkJSONTempObj.messages != undefined )
{
$.each(checkJSONTempObj.messages, function(key, value) {
var valJSONStr = $.toJSON(value);
var parameterJSON = eval("({'"+key+":"+instIndex+"':" + valJSONStr + "})");
$.extend(checkJSONInstObj.messages, parameterJSON);
});
}
var instForm = template.find("form");
instForm.validate(checkJSONInstObj);
}
function consoleLog(para)
{
if (typeof window.console == "undefined") {
window.console = {log: function() {}};
}
window.console.log( para );
}
function getInstIndexByPath(xml, OBJID, path)
{
var OBJ = $(xml).find(OBJID);
var instances = $("Instance", OBJ);
var instIndex = -1;
instances.each(function(i){
var inst = $(this);
inst.find("ParaName").each(function(){
var ParaName = $(this).text();
var ParaValue = $(this).next().text();
if ( ParaName.match(/^_InstID/) != null
&& ParaValue == path )
{
instIndex = i;
}
});
});
return instIndex;
}
function getParaValueInXML(xml, OBJID, InstIndex, paraNameIn)
{
var paraValueOut = "N/A";
var OBJ = $(xml).find(OBJID);
var instances = $("Instance", OBJ);
var inst = instances.eq(InstIndex);
inst.find("ParaName").each(function(){
var ParaName = $(this).text();
var ParaValue = $(this).next().text();
if ( ParaName == paraNameIn )
{
paraValueOut = ParaValue;
return false;
}
});
return paraValueOut;
}
function colorTblRow(tblClass, rowAttr, Head)
{
$(tblClass+">div", Head).each(function(){
var thisDiv = $(this);
thisDiv.removeClass("colorRow");
});
$(tblClass+">div:"+rowAttr, Head).each(function(){
var thisDiv = $(this);
if (thisDiv.hasClass("titleRow") == false)
{
thisDiv.addClass("colorRow");
}
});
}
jQuery.fn.collapsibleInstTitleChange = function(referenceID) {
var ContainerOBJ = $(this);
var NameValue = $("[id^='"+referenceID+":']",ContainerOBJ).attr("value");
var instNameObj = $(".collapsibleInst",ContainerOBJ);
instNameObj.text(NameValue);
instNameObj.attr("title", NameValue);
}
function initialCtrlAllLink(containerOBJ)
{
var AllObj = $(".AllOn, .AllOff",containerOBJ);
AllObj.unbind("click");
AllObj.click(function(event){
var AllCtlItme = $(this);
var Head = AllCtlItme.parents(".HeadDIV");
var Template = AllCtlItme.parents("[id^='template_']");
var needCheck = 1;
var EleSelectValue;
if ( AllCtlItme.hasClass("AllOn") )
{
needCheck = 1;
EleSelectValue = 1;
}
else if ( AllCtlItme.hasClass("AllOff") )
{
needCheck = 0;
EleSelectValue = 0;
}
else
{
}
if ( AllCtlItme.attr("EleSelectValue") )
{
EleSelectValue = AllCtlItme.attr("EleSelectValue");
}
$(":radio",Template).each(function(){
var RadioOBJ = $(this);
if ( RadioOBJ.attr("value") == EleSelectValue )
{
RadioOBJ.attr("checked", "checked");
}
else
{
RadioOBJ.removeAttr("checked");
}
});
$(":checkbox",Template).each(function(){
var CheckboxOBJ = $(this);
if ( needCheck == 1)
{
CheckboxOBJ.attr("checked", "true");
}
else
{
CheckboxOBJ.removeAttr("checked");
}
});
});
}
function ActionByApplyResult(xml, template, TitleValueReferID)
{
var isError = template.hasError(xml);
if (isError == 0)
{
succHintShow(template);
var _InstIDOBJ = $(xml).find("_InstID");
if (_InstIDOBJ.length > 0)
{
$("[id^='_InstID']",template).attr("value", _InstIDOBJ.text());
}
if ( TitleValueReferID != undefined )
{
template.collapsibleInstTitleChange(TitleValueReferID);
}
}
return isError;
}
function ActionByCancelResult(xml, template, OBJIDForFillData, TitleValueReferID)
{
var isError = template.hasError(xml);
if ( isError == 0 )
{
template.fillDataByOBJID(xml, OBJIDForFillData, template, 0);
if ( TitleValueReferID != undefined )
{
template.collapsibleInstTitleChange(TitleValueReferID);
}
}
else
{
$(".ChangeArea",template).showIt(true);
$(".collapsibleInst",template).addClass("instNameExp");
}
return isError;
}
function addInst(Head, InstNumOBJ)
{
var HeadID = Head.attr("id");
var templateOBJ = $("#template_"+HeadID);
var suffix = InstNumOBJ.attr("value");
var clone = templateOBJ.cloneWithSuffix(suffix);
templateOBJ.before(clone);
InstNumOBJ.attr("value",parseInt(suffix)+1);
clone.showIt(true);
$(".collapsibleInst",clone).addClass("instNameExp");
$(".ChangeArea",clone).showIt(true);
}
function collapBarAction(collapBar)
{
var Head = collapBar.parents(".HeadDIV");
var HeadID = Head.attr("id");
var containerMainID = HeadID + "_container";
var UnderControlContainer = $("#"+containerMainID, Head);
var template = collapBar.parents("[id^='template_']");
var selector = "[id^='"+ containerMainID +"']";
var containerInTemp = $(selector, template);
var containerLen = containerInTemp.length;
if ( containerLen > 0 )
{
UnderControlContainer = containerInTemp;
}
if ( UnderControlContainer.is(":visible") )
{
UnderControlContainer.showIt(false);
collapBar.removeClass("collapsibleBarExp");
}
else
{
UnderControlContainer.showIt(true);
collapBar.addClass("collapsibleBarExp");
}
var InstNumOBJ = $("#_InstNum",Head);
var AddInstLink = Head.find(".addInst");
var ExistInst = 0;
$("[id^='template_']",Head).each(function(){
if ($(this).css("display") == "block")
{
ExistInst = 1;
return false;
}
});
if ( ExistInst == 0
&& AddInstLink.length > 0 )
{
addInst(Head, InstNumOBJ);
}
}
function initial_collapBarWithDataTrans(Head)
{
var UnderControlContainer = $("#"+ Head.attr("id") +"_container");
UnderControlContainer.hide();
$(".collapBarWithDataTrans",Head).click(function(event){
event.preventDefault();
var collapBar = $(this);
if ( $("#DataHasBeenGot",Head).val() == 0 )
{
showWaitTip(true);
setTimeout(function(){
var ServerAddr = $("address span", Head).text();
Head.dataTransfer(ServerAddr,
"GET",
Head.succfunction,
undefined,
undefined,
false
);
$("#DataHasBeenGot",Head).val(1);
collapBarAction(collapBar);
}, 2);
}
else
{
collapBarAction(collapBar);
}
});
}
function initial_CollapsibleBar()
{
$(".collapsibleBar").each(function(){
var HeadID = $(this).parents(".HeadDIV").attr("id");
var UnderControlContainer = $("#"+ HeadID +"_container");
UnderControlContainer.hide();
});
$(".collapsibleBar").each(function(){
var collapsibleBar = $(this);
collapsibleBar.click(function(event){
event.preventDefault();
var collapBar = $(this);
collapBarAction(collapBar);
});
});
}
function initial_addInstLink()
{
$(".addInst").each(function(event){
var addInstOBJ = $(this);
addInstOBJ.unbind("click");
addInstOBJ.click(function(event){
var Head = $(this).parents(".HeadDIV");
var InstNumOBJ = $("#_InstNum",Head);
addInst(Head, InstNumOBJ);
});
});
}
